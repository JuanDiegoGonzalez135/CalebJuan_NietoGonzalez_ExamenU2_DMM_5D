import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { MaterialIcons } from "@expo/vector-icons";

import Perfil from './Perfil';
import Search from './Buscar';
import { Image } from "@rneui/base";

const Tab=createBottomTabNavigator();

const TabNav=()=>{
    return(
        <Tab.Navigator style={{height: 10}} initialRouteName="Perfil">
            <Tab.Screen
            name="Perfil"
            component={Perfil}
            options={{
                headerShown:false,
                tabBarActiveTintColor:'#0833A2',
                tabBarInactiveTintColor:'#129E9E',
                tabBarLabelStyle:{fontSize:15},
                tabBarIcon: ({size,color}) =>{
                  <Image style={{width: size, height: size, borderColor: color, borderWidth: 2}} source={require('../img/1704421462074.jpg')}/>
                }
            }} />
            <Tab.Screen
            name="Search"
            component={Search}
            options={{
                headerShown:false,
                tabBarActiveTintColor:'#0833A2',
                tabBarInactiveTintColor:'#129E9E',
                tabBarLabelStyle:{fontSize:15},
                tabBarIcon: ({size,color}) =>{
                    <MaterialIcons name="settings"
                    color={color}
                    size={size} />
                }
            }} />
        </Tab.Navigator>

    )
}

export default  TabNav;