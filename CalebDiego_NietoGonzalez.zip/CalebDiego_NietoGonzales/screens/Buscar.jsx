import { Card, Image } from '@rneui/themed';
import { StyleSheet, Text, TextInput, View } from 'react-native';

export default function Busqueda() {
  return (
    <View style={styles.container}>
      
      <View style={{margin:20}}>
      <TextInput style={{backgroundColor:"grey", flexDirection:"row", marginTop:20, borderRadius:20, height:25, textAlign:'center'}}></TextInput>
      </View>
      <View style={styles.imgs}>
        <Image source={require('../img/1704592841192.jpg')} style={{width:100,height:100}} />
        <Image source={require('../img/1704421462074.jpg')} style={{width:100,height:100}} />
        <Image source={require('../img/1704421462074.jpg')} style={{width:100,height:100}} />
      </View>
      <View style={styles.imgs}>
        <Image source={require('../img/1704421462074.jpg')} style={{width:100,height:100}} />
        <Image source={require('../img/1705364299754.jpg')} style={{width:100,height:100}} />
        <Image source={require('../img/1706625321360.jpg')} style={{width:100,height:100}} />
      </View>
      <View style={styles.imgs}>
        <Image source={require('../img/1708796081767.jpg')} style={{width:100,height:100}} />
        <Image source={require('../img/1708288947206.jpg')} style={{width:100,height:100}} />
        <Image source={require('../img/1704421462074.jpg')} style={{width:100,height:100}} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  imgs:{
    alignItems:'center', 
    justifyContent:'center',
    flexDirection:'row'
  }
});