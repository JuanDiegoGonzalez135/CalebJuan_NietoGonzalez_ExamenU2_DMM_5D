import { Image } from '@rneui/themed';
import { StyleSheet, Text, View } from 'react-native';

export default function Perfil() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View styles={styles.container2}>
            <Image style={styles.profileImg} source={require('../img/1704421462074.jpg')}/>
            <Text style={styles.text}>Diego</Text>
        </View>
        <View styles={styles.container2}>
          <Text style={styles.text}>9</Text>
          <Text style={styles.text}>Publicaciones</Text>
        </View>
        <View styles={styles.container2}>
          <Text style={styles.text}>120k</Text>
          <Text style={styles.text}>Seguidores</Text>
        </View>
        <View styles={styles.container2}>
          <Text style={styles.text}>10</Text>
          <Text style={styles.text}>Seguidos</Text>
        </View>
      </View>
      <View style={styles.stories}>
        <View styles={styles.container2}>
            <Image style={styles.storiesImg} source={require('../img/1704592841192.jpg')}/>
            <Text style={styles.textStories}>Me</Text>
        </View>
        <View styles={styles.container2}>
            <Image style={styles.storiesImg} source={require('../img/1704592880676.jpg')}/>
            <Text style={styles.textStories}>Vacations</Text>
        </View>
        <View styles={styles.container2}>
            <Image style={styles.storiesImg} source={require('../img/1708879971833.jpg')}/>
            <Text style={styles.textStories}>Summer</Text>
        </View>
        <View styles={styles.container2}>
            <Image style={styles.storiesImg} source={require('../img/1708010531666.jpg')}/>
            <Text style={styles.textStories}>School</Text>
        </View>
      </View>
      <View style={styles.feed}>
        <View styles={styles.feedImgContainer}>
          <Image style={styles.feedImg} source={require('../img/mona.jpg')}/>
          <Image style={styles.feedImg} source={require('../img/flores.jpg')}/>
          <Image style={styles.feedImg} source={require('../img/grand.jpg')}/>
        </View>
        <View styles={styles.feedImgContainer}>
          <Image style={styles.feedImg} source={require('../img/men.jpg')}/>
          <Image style={styles.feedImg} source={require('../img/calle.jpg')}/>
          <Image style={styles.feedImg} source={require('../img/guy.jpg')}/>
        </View>
        <View styles={styles.feedImgContainer}>
          <Image style={styles.feedImg} source={require('../img/montain.jpg')}/>
          <Image style={styles.feedImg} source={require('../img/1704421462074.jpg')}/>
          <Image style={styles.feedImg} source={require('../img/cakes.jpg')}/>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    flex: 1,
    backgroundColor: '#000',
    padding: 5
  },
  profileImg: {
    borderRadius: 50,
    width: 70,
    height: 70
  },
  container2:{
    flexDirection: 'row',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  text: {
    color: 'white',
    textAlign: 'center',
    fontSize: 15
  },
  textStories: {
    color: 'white',
    textAlign: 'center',
    fontSize: 15,
    fontFamily: ''
  },
  storiesImg: {
    borderRadius: 50,
    width: 70,
    height: 70,
    borderColor: 'green',
    borderWidth: 2
  },
  header:{
    flexDirection: 'row',
    marginTop: 30,
    alignItems: 'center',
    justifyContent: 'space-around'
  },
  stories: {
    flexDirection: 'row',
    marginTop: 40,
    padding: 2,
    alignItems: 'center',
    justifyContent: 'space-evenly'
  },
  feed:{
    flexDirection: 'row',
    marginTop: 40,
    padding: 2,
    alignItems: 'center',
    justifyContent: 'space-evenly'
  },
  feedImgContainer:{
    flexDirection: 'column'
  },
  feedImg: {
    width: 120,
    height: 150
  }
});
