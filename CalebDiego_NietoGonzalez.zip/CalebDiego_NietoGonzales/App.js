import { NavigationContainer} from "@react-navigation/native";

import TabNav from "./screens/tabNav";

export default function Perfil() {
  return (
    <NavigationContainer>
    <TabNav/>
  </NavigationContainer>
  );
}
